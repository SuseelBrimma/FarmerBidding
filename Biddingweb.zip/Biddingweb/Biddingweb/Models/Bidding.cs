﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Biddingweb.Models
{
    public class Bidding
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int BiddingAmount { get; set; }
        public String CustomerName { get; set; }
        public String CustomerEmail { get; set; }
        public String CustomerAddress { get; set; }
    }

}