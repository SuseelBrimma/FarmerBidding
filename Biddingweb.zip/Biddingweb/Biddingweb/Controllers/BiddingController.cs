﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Biddingweb.Models;

namespace Biddingweb.Controllers
{
    public class BiddingController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            String query = @"
                      select ProductID,ProductName,BiddingAmount,CustomerName,CustomerEmail,CustomerAddress
                      from dbo.Bidding
                          ";
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["AddProductAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string post(Bidding add)
        {
            try
            {
                DataTable table = new DataTable();
                String query = @"
                      insert into dbo.Bidding 
                      (ProductName,
                       BiddingAmount,
                       CustomerName,
                       CustomerEmail,
                       CustomerAddress
                       )
                       values 
                       (
                        '" + add.ProductName + @"'
                        ,'" + add.BiddingAmount + @"'
                        ,'" + add.CustomerName + @"'
                        ,'" + add.CustomerEmail + @"'
                        ,'" + add.CustomerAddress + @"'
                        )
                          ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["AddProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception)
            {
                return "Failed to Add";
            }
        }
    }
}
