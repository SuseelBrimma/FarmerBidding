﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Biddingweb.Models;

namespace Biddingweb.Controllers
{
    public class AddProductController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();
            String query = @"
                      select ProductID,ProductName,ProductPrice,ProductQuantity,BidStart
                      from dbo.AddProduct
                          ";
            using(var con = new SqlConnection(ConfigurationManager.ConnectionStrings["AddProductAppDB"].ConnectionString))
            using(var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

         public string post(AddProduct add)
        {
            try
            {
                DataTable table = new DataTable();
                String query = @"
                      insert into dbo.AddProduct 
                      (ProductName,
                       ProductPrice,
                       ProductQuantity,
                       BidStart)
                       values 
                       (
                        '" +add.ProductName + @"'
                        ,'" +add.ProductPrice +@"'
                        ,'" +add.ProductQuantity + @"'
                        ,'" +add.BidStart + @"'
                        )
                          ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["AddProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception) 
            {
                return "Failed to Add";
            }
        }

        public string put(AddProduct add)
        {
            try
            {
                DataTable table = new DataTable();
                String query = @"
                   update dbo.AddProduct set
                ProductName = '" + add.ProductName + @"'
                ,ProductPrice = '" + add.ProductPrice + @"'
                ,ProductQuantity = '" + add.ProductQuantity +@"'
                ,BidStart = '" + add.BidStart + @"'
                 where ProductID = " + add.ProductId +@"
                          ";
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["AddProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "updated Successfully";
            }
            catch (Exception)
            {
                return "Failed to update";
            }
        }

        public string Delete(int id)
        {
            try
            {
                DataTable table = new DataTable();
                String query = @"
                  delete from dbo.AddProduct where ProductID = " + id;
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["AddProductAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Delete Successfully";
            }
            catch (Exception)
            {
                return "Failed to delete";
            }
        }

    }
}
